//package Sorting;
//
//public class SSort {
//    int i = 0;
//    int j;
//    int imaks;
//    int maks;
//    int temp;
//
//    for (int i = arr)
//}
